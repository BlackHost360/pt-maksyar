<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'zakanixi_wp814' );

/** Database username */
define( 'DB_USER', 'zakanixi_wp814' );

/** Database password */
define( 'DB_PASSWORD', 'S942p)Wbf@' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'girzu114jla9q94ywlydocbm9vgpxcultdq8mhlmky2dagvf8cdqtfs3sydmagko' );
define( 'SECURE_AUTH_KEY',  '4juzlnknriajfvvvwro97revauaoe3k6cvnacvavkoahvpgvuhvvk8fzx1lx75he' );
define( 'LOGGED_IN_KEY',    '1dg3wez8rhjlstdxn8nztfvfrpqe0llesikzubhlh10npqip8rreyb8b9vrb0fuy' );
define( 'NONCE_KEY',        'gp0jl3dwkjoec3ffffeotoovj81s1rudb5ikduiuksknhjlazqfwq9yh8lkhrtms' );
define( 'AUTH_SALT',        't5sm7iccj9onscna1zqgzrm35evrjevy0tuxf6a9j0zy9nigrhgk4do7vpkyecxc' );
define( 'SECURE_AUTH_SALT', 'bb0aowmizq4adnu1j5mcfpzxulkrkmvjnddwszokimiuafru89ljsqocypxuo2kf' );
define( 'LOGGED_IN_SALT',   '3tvptacfijswrlq3kg6njs7fg55p9vqvmz0tykmodcfg7lfp7qrc4bnyilfrernw' );
define( 'NONCE_SALT',       '8eplib85qq1d3jo0omefvgxipsj8oylrnlnbnwmrau1mnlakp18a1zjvg7dncxo3' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wpzh_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
